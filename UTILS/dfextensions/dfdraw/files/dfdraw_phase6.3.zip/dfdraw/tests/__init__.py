"""
Tests for dfdraw package.
"""
